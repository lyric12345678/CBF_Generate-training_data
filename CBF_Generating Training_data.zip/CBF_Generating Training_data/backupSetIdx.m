function h = backupSetIdx(xi,pv,i)
x = zeros(4,1);
x(i) = xi;
h = backupSet(x,pv);
end