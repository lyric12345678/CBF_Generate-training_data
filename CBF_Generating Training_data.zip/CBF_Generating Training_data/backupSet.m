%%
function h = backupSet(x,pv)
global P

x = x(:);
h = pv-x'*P*x;
% Dh = x'*(P+P');
end