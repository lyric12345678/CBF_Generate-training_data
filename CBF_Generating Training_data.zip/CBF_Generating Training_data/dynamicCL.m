%%
function xDot = dynamicCL(~,x)
global K model xEq
[f,g] = SegwayDyn(x,model);

xDot = f - g*K*(x-xEq);
end
